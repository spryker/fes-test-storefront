import { Provider } from '@spryker-oryx/injector';
export declare function fesInjectorSetup(context: any, inject: any, providers?: Provider[]): void;
