export interface ComponentData {
    items: any;
}
export interface DynamicComponent {
    id: string;
    type: string;
}
export declare type componentRegistrationFn = (name: string, context?: any) => void;
export declare type checkComponentRegistrationFn = (name: string) => boolean;
export declare type getComponentNameFn = (componentType: string) => string;
export declare type resolveComponentNameFn = (component: DynamicComponent, context?: any) => string | null;
export interface WebComponentMapper {
    webComponentScript: string;
    name: string;
}
export interface VueComponentMapper {
    componentFactory: Function;
    name?: string;
}
export interface ComponentMappings {
    [key: string]: WebComponentMapper | VueComponentMapper;
}
