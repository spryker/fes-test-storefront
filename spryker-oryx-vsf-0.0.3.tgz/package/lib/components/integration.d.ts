export declare const INTEGRATION_TAG = "spryker/layout";
