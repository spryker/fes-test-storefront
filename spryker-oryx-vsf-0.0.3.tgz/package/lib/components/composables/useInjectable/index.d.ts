export default function useInjectable<K extends keyof InjectionTokensContractMap>(injectionToken: K | string): InjectionTokensContractMap[K];
