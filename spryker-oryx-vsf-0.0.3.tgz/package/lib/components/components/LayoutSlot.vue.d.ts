import Vue from 'vue';
declare const _default: import("vue/types/vue").ExtendedVue<Vue, unknown, unknown, unknown, {
    slotName: string;
    componentId: string;
}>;
export default _default;
