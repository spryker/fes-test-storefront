import { FactoryProvider } from '@spryker-oryx/injector';
export declare const contentBackendProvider: FactoryProvider;
