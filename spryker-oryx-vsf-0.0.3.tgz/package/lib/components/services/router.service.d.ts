import { RouterContract, RouterEvent, RouterEventType } from '@spryker-oryx/experience';
import { Observable } from 'rxjs';
export declare class RouterService implements RouterContract {
    private platform;
    private router;
    private routerEvents$;
    constructor();
    go(route: string): void;
    getEvents(type: RouterEventType): Observable<RouterEvent>;
}
