import { resolveComponentNameFn } from '../types';
declare const resolveComponentName: resolveComponentNameFn;
export { resolveComponentName };
