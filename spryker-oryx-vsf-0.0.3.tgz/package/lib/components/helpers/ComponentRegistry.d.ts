import { VueComponentMapper, WebComponentMapper } from '../types';
export declare class ComponentRegistry {
    private components;
    private webComponentsScriptsLink;
    register(type: string, component: WebComponentMapper | VueComponentMapper): void;
    getComponent(type: string): WebComponentMapper | VueComponentMapper;
    setWebComponentScriptsLinks(script: string): void;
    isWebComponentScriptRegistered(script: string): boolean;
}
export declare function getRegisteredComponent(type: string): WebComponentMapper | VueComponentMapper;
export declare function registerComponent(type: string, component: WebComponentMapper | VueComponentMapper): void;
export declare function isWebComponentScriptRegistered(script: string): boolean;
export declare function setWebComponentScriptsLinks(webComponentFileLink: string): void;
