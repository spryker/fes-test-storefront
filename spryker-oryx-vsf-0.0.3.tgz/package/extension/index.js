'use strict';

var integration = require('@spryker-oryx/vsf/lib/integration');

// import FaasCore from '@spryker-vsf/faas-core';

var extension = {
  name: integration.INTEGRATION_TAG,
  // extendApiMethods: {
  //   FaasCore,
  // },
};

module.exports = extension;
//# sourceMappingURL=index.js.map
